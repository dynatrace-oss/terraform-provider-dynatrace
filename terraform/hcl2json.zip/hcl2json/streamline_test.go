/**
* @license
* Copyright 2020 Dynatrace LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
 */

package hcl2json_test

import (
	"encoding/json"
	"sort"
)

func streamline(v interface{}) interface{} {
	if v == nil {
		return nil
	}
	switch tv := v.(type) {
	case bool:
		return nil
	case string:
		if len(tv) == 0 {
			return nil
		}
	case map[string]interface{}:
		for k, v := range tv {
			av := streamline(v)
			if av == nil {
				delete(tv, k)
			} else {
				tv[k] = av
			}
		}
		if len(tv) == 0 {
			return nil
		}
	case []string:
		if len(tv) == 0 {
			return nil
		}
		sort.Strings(tv)
	case []int:
		if len(tv) == 0 {
			return nil
		}
	case []float64:
		if len(tv) == 0 {
			return nil
		}
	case []interface{}:
		if len(tv) == 0 {
			return nil
		}
		jsons := []string{}
		for _, v := range tv {
			byt, _ := json.Marshal(streamline(v))
			jsons = append(jsons, string(byt))
		}
		sort.Strings(jsons)
		for idx, je := range jsons {
			json.Unmarshal([]byte(je), &tv[idx])
		}
	}
	return v
}
